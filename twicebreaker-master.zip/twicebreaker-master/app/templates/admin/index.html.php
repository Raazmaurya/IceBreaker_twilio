<h2>Admin Login</h2>

<form role="form" action="/admin" method="post">
  <div class="form-group">
    <label for="inputPassword">Password</label>
    <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Admin Password">
  </div>
  <button type="submit" class="btn btn-default">Login</button>
</form>

