<?php echo '<?xml version=\"1.0\" encoding=\"UTF-8\"?>'; ?>
<Response>
  <Message><?php echo $message; ?></Message>
</Response>
